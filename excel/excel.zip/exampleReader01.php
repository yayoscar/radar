<?php

error_reporting(E_ALL);
set_time_limit(0);


?>
<html>
<head>
 <meta name="tipo_contenido"  content="text/html;" http-equiv="content-type" charset="utf-8">

<title>PHPExcel Reader Example #01</title>

</head>
<body>

<h1>PHPExcel Reader Example #01</h1>
<h2>Simple File Reader using PHPExcel_IOFactory::load()</h2>
<?php


/** PHPExcel_IOFactory */
include '../class/PHPExcel/IOFactory.php';

 function mayus($str){
     $str=utf8_decode($str);
	 $cadena = strtr(strtoupper($str), "���������������������������","���������������������������");
     //$cadena = ucwords(strtolower($cadena));   
     return $cadena; 
   }

$inputFileName = 'BD.xlsx';
echo 'Loading file ',pathinfo($inputFileName,PATHINFO_BASENAME),' using IOFactory to identify the format<br />';
$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);


echo '<hr />';

$especialidades = $objPHPExcel->getSheetByName('especialidad')->toArray(null,true,true,true);


$mysqli = new mysqli("localhost", "root", "", "radardgeti");

$ban=0;
foreach($especialidades as $especialidad){
	if(!$ban){
		$ban=1;
	}
	else
	{
		$clave=strtoupper($especialidad["A"]);
		$nombre=$nombre_corto=mayus($especialidad["B"]);
		$observacion=mayus($especialidad["C"]);
			
		$sql="insert into especialidad (clave,nombre,nombre_corto,observacion) values (
				'$clave','$nombre','$nombre_corto','$observacion')";
				
		echo "$sql<br>";
		$mysqli->query($sql);

	}
}


?>
<body>
</html>